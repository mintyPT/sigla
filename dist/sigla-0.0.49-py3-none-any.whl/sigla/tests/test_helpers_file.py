class TestOther:
    pass

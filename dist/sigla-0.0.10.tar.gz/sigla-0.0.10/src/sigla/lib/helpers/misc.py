def cast_array(v):
    if type(v) == list:
        return v
    return [v]

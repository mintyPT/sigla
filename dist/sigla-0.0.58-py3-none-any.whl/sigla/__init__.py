from sigla.conf.config import config  # noqa F401
from sigla.sigla import from_xml_string, from_xml_file  # noqa F401

__version__ = "0.0.58"
